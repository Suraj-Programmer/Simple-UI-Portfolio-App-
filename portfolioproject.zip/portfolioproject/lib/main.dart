import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    ),
  ); //
}

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image:DecorationImage(
            fit:BoxFit.cover,
                image:
              AssetImage("assets/surya.jpg"),
          )
          ,
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 100.0, left: 20),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  const CircleAvatar(
                      radius: 40,
                      backgroundImage: AssetImage('assets/suraj.jpeg')),
                  SizedBox(
                    width: 20,
                  ),
                  Column(
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: const [
                          Text(
                            "Suraj Prajapati",
                            style: TextStyle(
                              fontSize: 30,
                              fontFamily: "coder",
                              color: Colors.white
                            ),
                          ),
                          Text(
                            "Flutter Developer",
                            style: TextStyle(
                              fontSize: 15,
                                fontFamily: "coder",
                              color: Colors.white
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(
                height: 40,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(

                          Icons.school,
                          color: Colors.white,
                          size: 30,
                        ),
                        const SizedBox(
                          width: 25,
                        ),
                      Expanded(child: Text(
                          "Dr APJ Abdul Kalam Technical University",
                          style: TextStyle(
                            fontSize: 17,  color: Colors.white,
                            fontFamily: "coder",
                          ),
                      ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.computer_rounded,
                          color: Colors.white,
                          size: 30,
                        ),
                        SizedBox(
                          width: 25,
                        ),
                        Text(
                          "PortFolio App",
                          style: TextStyle(
                            fontSize: 17,
                              fontFamily: "coder",
                              color: Colors.white
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.location_on,
                          color: Colors.white,
                          size: 30,

                        ),
                        SizedBox(
                          width: 25,
                        ),
                        Text(
                          "Aligarh ,Uttar Pradesh 202001",
                          style: TextStyle(
                            fontSize: 17,
                              fontFamily: "coder",
                              color: Colors.white
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.mail,
                          color: Colors.white,
                          size: 30,
                        ),
                        SizedBox(
                          width: 25,
                        ),
                        Text(
                          "surajoneness123@gmail.com",
                          style: TextStyle(
                            fontSize: 17,

                              fontFamily: "coder",

                              color: Colors.white

                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.phone,
                          color: Colors.white,
                          size: 30,
                        ),
                        SizedBox(
                          width: 25,
                        ),
                        Text(
                          "7217466604",
                          style: TextStyle(
                            fontSize: 17,
                              fontFamily: "coder",
                              color: Colors.white
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "About me : ",
                  style: TextStyle(
                    fontSize: 15,
                      fontFamily: "coder",
                      color: Colors.white
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "Talented individual with in-depth knowledge of designing and development tools and coding languages. Desirous of the role of Software Developer at AP Inc. to apply 2+ years of work experience in innovating software designs, testing and coding as well as debugging programs and troubleshooting and augmenting the company’s reputation.",style: TextStyle(fontSize: 12,color: Colors.yellow)

                ),
              ),
              Text(
                "Created by Suraj Prajapati",
                style: TextStyle(
                  fontSize: 15,
                    fontFamily: "coder",
                    color: Colors.white
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
